package com.pleiterson.introducaospringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntroducaoSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
